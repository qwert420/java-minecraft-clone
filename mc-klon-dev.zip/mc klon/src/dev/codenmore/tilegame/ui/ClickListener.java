package dev.codenmore.tilegame.ui;

public interface ClickListener {
	
	public void onClick();

}
