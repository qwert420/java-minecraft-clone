package dev.codenmore.tilegame;


public class Launcher {

	public static void main(String[] args){
		Game game = new Game("minecraft lol", 920, 830);
		game.start();
	}
	
}
